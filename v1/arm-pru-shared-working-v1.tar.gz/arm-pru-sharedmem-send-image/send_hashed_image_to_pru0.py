#!/usr/bin/python3

from time import sleep
import math
import numpy as np
import hashlib
import os, mmap

PRU_ADDR = 0x4A300000
PRU_SHAREDMEM  = 0x10000
PRU_SHAREDMEM_SIZE = 12000
PRU_SHARED_MEM_HASH_LOC = PRU_ADDR + PRU_SHAREDMEM
PRU_SHARED_MEM_IMAGE_LOC = PRU_ADDR + PRU_SHAREDMEM + 16
IMAGE_OFFSET = 16

# fo = open("/dev/rpmsg_pru30", "wb", 0)
# fmem = open("/dev/mem", "wb", 0)
fmem = os.open('/dev/mem', os.O_RDWR | os.O_SYNC )
pru_shared_mem = mmap.mmap(fmem, PRU_SHAREDMEM_SIZE, offset=PRU_ADDR+PRU_SHAREDMEM)

def gen_test_image(shape=[3,32,64], rowswapper=0 ):
    image = np.zeros(shape, dtype=np.uint8)

    RED_IND = 0
    GREEN_IND = 1
    BLUE_IND = 2
    print(image.shape)
    rowswapper = rowswapper % 4
    for row in range(image.shape[1]):
        if (row+rowswapper) % 4 ==  0:
            image[RED_IND,row,:] = 0xff
            image[GREEN_IND,row,:32] = 0xff
            image[GREEN_IND,row,32:] = 0
            image[BLUE_IND,row,32:] = 0xff
            image[BLUE_IND,row,:32] = 0
            
        if (row+rowswapper) % 4 ==  1:
            image[RED_IND,row,:32] = 0xff
            image[RED_IND,row,32:] = 0
            image[GREEN_IND,row,:] = 0xff
            image[BLUE_IND,row,32:] = 0xff
            image[BLUE_IND,row,:32] = 0

        if (row+rowswapper) % 4 ==  2:
            image[RED_IND,row,:16] = 0xff
            image[RED_IND,row,16:] = 0
            image[GREEN_IND,row,:16] = 0x0
            image[GREEN_IND,row,16:] = 0xff
            image[BLUE_IND,row,:] = 0xff
        
        if (row+rowswapper) % 4 ==  3:
            image[RED_IND,row,:] = 0xff
            image[GREEN_IND,row,:] = 0xff
            image[BLUE_IND,row,:] = 0xff



    return image

i=0

test_image = gen_test_image()
 
while i<128:
    print('send')
    
    test_image = gen_test_image(rowswapper=i)
    print(test_image)
    test_image[0,0,0] = test_image[0,0,0]-i
    md5 = hashlib.md5(test_image).digest()
    print(md5)
    pru_shared_mem.seek(0)
    pru_shared_mem.write(md5)
    pru_shared_mem.seek(IMAGE_OFFSET)
    pru_shared_mem.write(test_image.tobytes())

    #fo.write(bytes([i]));
    print('sleep...')
    sleep(0.1)
    i+=1

